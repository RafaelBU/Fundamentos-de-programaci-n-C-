#ifndef TLISTAJUGADORES_H
#define TLISTAJUGADORES_H

#include "tJugador.h"

// TIPOS //
//typedef tJugador tArrayJugadores[NUMERO_JUGADORES];
typedef tJugador *tTablaJugadorPtr; 

typedef struct{
	tTablaJugadorPtr tablaJugadores;
	//tArrayJugadores jugadores;
	int contador;
	int capacidadJugadores;
}tListaJugadores;

//Prototipos

//Funci�n que recibe como par�metro una lista de jugadores y devuelve un booleano indicando si la lista est� llena o no.
bool listaJugadoresLlena(tListaJugadores lista);

//Recibe como entrada una lista de jugadores y un nombre de usuario. Devuelve un booleano indicando si se ha encontrado el jugador ono y, 
//en caso afirmativo, la posici�n en la que se encuentra el jugador
int buscarPosJugador(tListaJugadores lista, tCadena usuario);

//Recibe una variable de tipo tJugador y una lista de jugadores. Inserta el jugador al final de la lista de jugadores
void insertarJugador(tJugador jugador, tListaJugadores &lista);

//Recibe un nombre de usuario, la lista de jugadores y la lista de edificios. Busca al jugador en la lista y lo elimina completamente
bool bajaJugador(tCadena usuario,tListaJugadores &listaJ, tListaEdificios &listaE);

//Funcion de redimensionar
void redimensionarListaJugadores (tListaJugadores & listaJugadores);
#endif